#pragma once
class AudioFilter
{
public:
	AudioFilter();
	~AudioFilter();
};

