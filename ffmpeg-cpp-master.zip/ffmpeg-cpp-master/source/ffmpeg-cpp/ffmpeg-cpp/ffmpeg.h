#pragma once

#define _CRTDBG_MAP_ALLOC  
#include <stdlib.h>  
#include <crtdbg.h> 

extern "C" {
	#include <..\include\libavcodec/avcodec.h>
	#include <..\include\libavutil/opt.h>
	#include <..\include\libavutil/imgutils.h>
	#include <..\include\libswscale/swscale.h>
	#include <..\include\libavformat/avformat.h>
	#include <..\include\libavutil/timestamp.h>
	#include <..\include\libavfilter/avfilter.h>
	#include <..\include\libavfilter/buffersink.h>
	#include <..\include\libavfilter/buffersrc.h>
	#include <..\include\libswresample/swresample.h>
	#include <..\include\libavutil/audio_fifo.h>
//#include <..\include\libavcodec\avcodec.h>
//#include <..\include\libavutil/opt.h>
//#include <..\include\libavutil/imgutils.h>
//#include <..\include\libswscale/swscale.h>
//#include <..\include\libavformat/avformat.h>
//#include <..\include\libavutil/timestamp.h>
//#include <..\include\libavfilter/avfilter.h>
//#include <..\include\libavfilter/buffersink.h>
//#include <..\include\libavfilter/buffersrc.h>
//#include <..\include\libswresample/swresample.h>
//#include <..\include\libavutil/audio_fifo.h>
//#include <..\include\libavutil/fifo.h>
}